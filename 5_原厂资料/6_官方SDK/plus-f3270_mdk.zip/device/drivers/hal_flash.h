/*
 * Copyright 2022 MindMotion Microelectronics Co., Ltd.
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __HAL_FLASH_H__
#define __HAL_FLASH_H__

#include "hal_common.h"

/*!
 * @addtogroup FLASH
 * @{
 */

#define FLASH_PAGE_SIZE    0x400 /*!< 1K Bytes. */

typedef enum
{
	FLASH_Latency_0_Cycle = 0u, /*!< for 0 < SYSCLK ≤ 24MHz. */
	FLASH_Latency_1_Cycle = 1u, /*!< 24MHz < SYSCLK ≤ 48MHz. */
	FLASH_Latency_2_Cycle = 2u, /*!< 48MHz < SYSCLK ≤ 72MHz. */
	FLASH_Latency_3_Cycle = 3u, /*!< 72MHz < SYSCLK ≤ 96MHz. */
	FLASH_Latency_4_Cycle = 4u, /*!< 96MHz < SYSCLK ≤ 120MHz. */
} FLASH_Latency_Type;


/* FLASH_STATUS. */
#define FLASH_STATUS_BUSY                 (1u << 0)
#define FLASH_STATUS_PROGRAM_ERR          (1u << 2u)
#define FLASH_STATUS_WRITE_PROTECTION_ERR (1u << 4u)
#define FLASH_STATUS_END_OF_OPERATION     (1u << 5u)

/* FLASH_CMD. */
#define FLASH_CMD_PROGRAM     FLASH_CR_PG_MASK
#define FLASH_CMD_PROGRAM_OPT FLASH_CR_OPTPG_MASK
#define FLASH_CMD_ERASE_PAGE  FLASH_CR_PER_MASK
#define FLASH_CMD_ERASE_MASS  FLASH_CR_MER_MASK
#define FLASH_CMD_ERASE_OPT   FLASH_CR_OPTER_MASK
#define FLASH_CMD_START_ERASE FLASH_CR_STRT_MASK
#define FLASH_CMD_ALL ( FLASH_CMD_PROGRAM \
                      | FLASH_CMD_ERASE_PAGE \
                      | FLASH_CMD_ERASE_MASS \
                      | FLASH_CMD_PROGRAM_OPT \
                      | FLASH_CMD_ERASE_OPT \
                      | FLASH_CMD_START_ERASE )

void FLASH_SetLatency(FLASH_Type *FLASHx, FLASH_Latency_Type opt);
void FLASH_EnablePrefetch(FLASH_Type *FLASHx, bool enable);
void FLASH_Unlock(FLASH_Type * FLASHx);
void FLASH_Lock(FLASH_Type * FLASHx);
void FLASH_UnlockOptionBytes(FLASH_Type * FLASHx);
void FLASH_LockOptionBytes(FLASH_Type * FLASHx);
uint32_t FLASH_GetStatus(FLASH_Type * FLASHx);
void FLASH_ClearStatus(FLASH_Type * FLASHx, uint32_t flags);
bool FLASH_WaitDone(FLASH_Type * FLASHx, uint32_t timeout);
void FLASH_SetCmd(FLASH_Type * FLASHx, uint32_t cmd);
void FLASH_ClearCmd(FLASH_Type * FLASHx);
void FLASH_SetAddr(FLASH_Type * FLASHx, uint32_t addr);
void FLASH_SetData16b(uint32_t addr, uint16_t value);

/*!
 *@}
 */

#endif /* __HAL_FLASH_H__ */

