/*
 * Copyright 2022 MindMotion Microelectronics Co., Ltd.
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "pin_init.h"
#include "hal_rcc.h"
#include "hal_gpio.h"

/*
 * TXD1 - PA9.
 * RXD1 - PA10.
 * MCO - PTC9
 */
void BOARD_InitPins(void)
{
    /* PA9 - UART1_TX. */
    GPIO_Init_Type gpio_init;
    gpio_init.Pins  = GPIO_PIN_9;
    gpio_init.PinMode  = GPIO_PinMode_AF_PushPull;
    gpio_init.Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init);
    GPIO_PinAFConf(GPIOA, GPIO_PIN_9, GPIO_AF_7);
    
    /* PA10 - UART1_RX. */
    gpio_init.Pins  = GPIO_PIN_10;
    gpio_init.PinMode  = GPIO_PinMode_In_Floating;
    gpio_init.Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init);
    GPIO_PinAFConf(GPIOA, GPIO_PIN_10, GPIO_AF_7);
    
    /* PB6 - I2C_SCL.  PB7 - I2C_SDA. */
    RCC_EnableAHB1Periphs(RCC_AHB1_PERIPH_GPIOB, true);
	GPIO_Init_Type  init ={0};
	init.Pins  = GPIO_PIN_6  |GPIO_PIN_7;
    init.PinMode  = GPIO_PinMode_AF_OpenDrain;
    init.Speed = GPIO_Speed_10MHz;
    GPIO_Init(GPIOB, &init);
	GPIO_PinAFConf(GPIOB, GPIO_PIN_6 | GPIO_PIN_7, GPIO_AF_4);
}


/* EOF. */

