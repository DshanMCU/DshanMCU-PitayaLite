/*
 * Copyright 2022 MindMotion Microelectronics Co., Ltd.
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "hal_common.h"
#include "clock_init.h"

#include "hal_rcc.h"

void CLOCK_ResetToDefault(void);
void CLOCK_BootToHSI96MHz(void);
void CLOCK_RTCToLSE(void);

void BOARD_InitBootClocks(void)
{
    CLOCK_ResetToDefault();
    CLOCK_BootToHSI96MHz();
    
    /* GPIOA. */
    RCC_EnableAHB1Periphs(RCC_AHB1_PERIPH_GPIOA, true);
    RCC_ResetAHB1Periphs(RCC_AHB1_PERIPH_GPIOA);
    
    /* GPIOC. */
    RCC_EnableAHB1Periphs(RCC_AHB1_PERIPH_GPIOC, true);
    RCC_ResetAHB1Periphs(RCC_AHB1_PERIPH_GPIOC);

    /* UART1. */
    RCC_EnableAPB2Periphs(RCC_APB2_PERIPH_UART1, true);
    RCC_ResetAPB2Periphs(RCC_APB2_PERIPH_UART1);

    /* RTC. */
    RCC_EnableAPB1Periphs(RCC_APB1_PERIPH_PWR, true);
    RCC_EnableAPB1Periphs(RCC_APB1_PERIPH_BKP, true);

    /* RTC clock source is LSE. */
    CLOCK_RTCToLSE();
}

/* Switch to HSI. */
void CLOCK_ResetToDefault(void)
{
    /* Switch to HSI. */
    RCC->CR |= RCC_CR_HSION_MASK; /* Make sure the HSI is enabled. */
    while ( RCC_CR_HSIRDY_MASK != (RCC->CR & RCC_CR_HSIRDY_MASK) )
    {
    }
    RCC->CFGR = RCC_CFGR_SW(0u); /* Reset other clock sources and switch to HSI. */
    while ( RCC_CFGR_SWS(0u) != (RCC->CFGR & RCC_CFGR_SWS_MASK) ) /* Wait while the SYSCLK is switch to the HSI. */
    {
    }
    
    /* Reset all other clock sources. */
    RCC->CR = RCC_CR_HSION_MASK;

    /* Disable all interrupts and clear pending bits. */
    RCC->CIR = RCC->CIR; /* clear flags. */
    RCC->CIR = 0u; /* disable interrupts. */
}

/*
* After reset, the chip is running with the HSI (8MHz) clock with the divider equals 6. 
* The board is using 8MHz crystal for the OSC module.
*/

void CLOCK_BootToHSE96MHz(void)
{
    
}

/* Enable the PLL and use the HSI as input clock source. */
void CLOCK_BootToHSI96MHz(void)
{
    /* Increase the power to CPU core. */
    RCC->APB1ENR |= (1u << 28u); /* enable PWR/DBG. */
    PWR->CR1 = (PWR->CR1 & ~PWR_CR1_VOS_MASK) | PWR_CR1_VOS(1u); /* 1.65V. */
    
    /* Setup PLL before enable it. */
    RCC->PLLCFGR = RCC_PLLCFGR_PLLSRC(0)   /* Use HSI as input source. */
                 | RCC_PLLCFGR_PLLMUL(23)  /* mul = 12, 24. */
                 | RCC_PLLCFGR_PLLDIV(1)   /* div = 2. */
                 | RCC_PLLCFGR_PLLLDS(1)   /* default. */
                 | RCC_PLLCFGR_PLLICTRL(3) /* default. */
                 ;

    /* Enable PLL. */
    RCC->CR |= RCC_CR_PLLON_MASK;
    while((RCC->CR & RCC_CR_PLLRDY_MASK) == 0)
    {
    }

    /* Enable the FLASH prefetch. */
    RCC->AHB1ENR |= (1u << 13u); /* enable the access to FLASH. */
    FLASH->ACR = FLASH_ACR_LATENCY(3u) /* setup divider. */
               | FLASH_ACR_PRFTBE_MASK /* enable flash prefetch. */
               ; 

    /* Setup the dividers for each bus. */
    RCC->CFGR = RCC_CFGR_HPRE(0)   /* div=1 for AHB freq. */
              | RCC_CFGR_PPRE1(0x4)  /* div=2 for APB1 freq. */
              | RCC_CFGR_PPRE2(0x4)  /* div=2 for APB2 freq. */
              | RCC_CFGR_USBPRE(1) /* div=2 for USB freq. */
              | RCC_CFGR_MCO(7)    /* use PLL/2 as output. */
              ;

    /* Switch the system clock source to PLL. */
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW_MASK) | RCC_CFGR_SW(2); /* Use PLL as SYSCLK */
   
    
    /* Wait till PLL is used as system clock source. */
    while ( (RCC->CFGR & RCC_CFGR_SWS_MASK) != RCC_CFGR_SWS(2) )
    {
    }
}

void CLOCK_RTCToLSE()
{
    RCC->BDCR |= RCC_BDCR_DBP_MASK;

    /* Reset BKP. */
    RCC->BDCR |= RCC_BDCR_BDRST_MASK;
    RCC->BDCR &= ~RCC_BDCR_BDRST_MASK;


    /* Enable LSE clock source. */
    RCC->BDCR |= RCC_BDCR_RTCSEL(1u);
    RCC->BDCR &= ~RCC_BDCR_LSEON_MASK;
    RCC->BDCR |= RCC_BDCR_LSEON_MASK;

    while (0u == (RCC->BDCR & RCC_BDCR_LSERDY_MASK) )
    {
    }
    RCC->BDCR |= RCC_BDCR_RTCEN_MASK;
}

/* EOF. */

