# uart_basic

## 实验流程

+ 初始化串口，配置时钟频率、波特率、字长、传输模式等信息。
+ 使能串口。
+ 主程序打印提示语句，然后进入死循环。
+ 循环中，会将串口接受的字符通过串口输出。

## 实验结果

uart_basic example.
uart_basic example is this. Test Date : 20220127.