/*
 * Copyright 2022 MindMotion Microelectronics Co., Ltd.
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board_init.h"

/*
 * Definitions.
 */

/*
 * Macros.
 */
#define MENU_MESSAGE "\r\nPress:\r\n\
\ta) for Run\r\n\
\tb) for LowPowerRun\r\n\
\tc) for Sleep\r\n\
\td) for LowPowerSleep\r\n\
\te) for Stop\r\n\
\tf) for DeepStop\r\n\
\tg) for Standby\r\n\
-->Pull PB15 down to wake up the MCU from Sleep, LowPowerSleep, Stop, DeepStop or Standby mode.\r\n\
Enter your input:"

/*
 * Variables.
 */
/* Configure sleep mode parameters. */
POWER_SleepConf_Type sleep_conf =
{
    .SleepOnExit = false,
    .WakeUpMode = POWER_WakeUp_Interrupt,
};

/* Configure stop mode parameters. */
POWER_StopConf_Type stop_conf =
{
    .DeepStop = false,
    .WakeUpMode = POWER_WakeUp_Interrupt,
};

/* Configure deep stop mode parameters. */
POWER_StopConf_Type deep_stop_conf =
{
    .DeepStop = true,
    .WakeUpMode = POWER_WakeUp_Interrupt,
};

/* Configure standby mode wake up pin parameters. */
PWR_StandbyWakeUpPinConf_Type StadnbyWakeUpPinConf =
{
    .Pins = BOARD_POWER_STANDBYWAKEUP_PORT,
    .TrgIn = PWR_StandbyWakeUpPinTriggerIn_FallingEdge,
};

/* Configure standby mode parameters. */
POWER_StandbyConf_Type standby_conf =
{
    .Delay = BOARD_POWER_STANDBYWAKEUP_DELAY,
    .WakeUpMode = POWER_WakeUp_Interrupt,
};

/*
 * Declerations.
 */
void app_exti_init(void);

/*
 * Functions.
 */
int main(void)
{
    BOARD_Init();

    printf("\r\npower_basic example.\r\n");

    /* set up exti and syscfg. */
    app_exti_init();

    while (1)
    {
        printf(MENU_MESSAGE);

        uint8_t ch = getchar();

        switch (ch)
        {
            case 'a':
                CLOCK_ResetToDefault();
                BOARD_ResetDebugConsole(BOARD_DEBUG_UART_FREQ);
                printf("\r\nMCU is going in run mode...\r\n");
                POWER_SelectMode(POWER_Mode_Run, NULL);
                break;
            case 'b':
                CLOCK_SetClock_2M();
                BOARD_ResetDebugConsole(BOARD_DEBUG_UART_FREQ_2M);
                printf("\r\nMCU is going in low power run mode...\r\n");
                POWER_SelectMode(POWER_Mode_LowPowerRun, NULL);
                break;
            case 'c':
                printf("\r\nMCU is going in sleep mode...\r\n");
                POWER_SelectMode(POWER_Mode_Sleep, &sleep_conf);
                break;
            case 'd':
                CLOCK_SetClock_2M();
                BOARD_ResetDebugConsole(BOARD_DEBUG_UART_FREQ_2M);
                printf("\r\nMCU is going in low power sleep mode...\r\n");
                POWER_SelectMode(POWER_Mode_LowPowerSleep, &sleep_conf);
                break;
            case 'e':
                printf("\r\nMCU is going in stop mode...\r\n");
                POWER_SelectMode(POWER_Mode_Stop, &stop_conf);
                break;
            case 'f':
                printf("\r\nMCU is going in deep stop mode...\r\n");
                POWER_SelectMode(POWER_Mode_DeepStop, &deep_stop_conf);
                break;
            case 'g':
                printf("\r\nMCU is going in standby mode...\r\n");
                POWER_EnableStandbyWakeUpPin(&StadnbyWakeUpPinConf);
                POWER_SelectMode(POWER_Mode_Standby, &standby_conf);
                break;
            default:
                break;
        }
    }
}

/* setup the external interrupt and system conf. */
void app_exti_init(void)
{
    /* setup syscfg for port and line. */
    SYSCFG_SetExtIntMux(BOARD_SYSCFG_EXTIPORT, BOARD_SYSCFG_EXTILINE);

    /* setup exti and enable. */
    EXTI_SetTriggerIn(BOARD_EXTI_PORT, BOARD_EXTI_LINE, EXTI_TriggerIn_FallingEdge);
    EXTI_EnableLineInterrupt(BOARD_EXTI_PORT, BOARD_EXTI_LINE, true);
    EXTI_EnableLineEvent(BOARD_EXTI_PORT, BOARD_EXTI_LINE, true);

    /* setup NVIC */
    NVIC_EnableIRQ(BOARD_EXTI_IRQN);
}

/* EXTI IRQ Handler */
void BOARD_EXTI_IRQHandler(void)
{
    uint32_t flags = EXTI_GetLineStatus(BOARD_EXTI_PORT);

    EXTI_ClearLineStatus(BOARD_EXTI_PORT, flags);
}

/* EOF. */
