# power_basic

## 实验过程

+ 配置各低功耗模式参数，初始化EXTI。

+ 通过串口读取用户输入的字符，进入指定功耗模式。

## 实验结果

power_basic example.

Press:
    a) for Run
    b) for LowPowerRun
    b) for Sleep
    d) for LowPowerSleep
    e) for Stop
    f) for DeepStop
    g) for Standby
 -->Pull PB15 down to wake up the MCU from Sleep, LowPowerSleep, Stop, DeepStop or Standby mode.
  Enter your input:
  MCU is going in run mode...
